import UIKit
import Darwin

var greeting = "Hello, playground"

enum Organization: String {
    
    case boss = "He is the Boss of a Company"
    case gm = "He is the General Manager of a Company"
    case manager = "He is the Manager"
    case teamLead = "HE is the Team Leader"
    
    
}

func ranks (type: Organization) -> String {
    
    switch type {
        
    case .boss:
        return Organization.boss.rawValue
    case .gm:
        return Organization.gm.rawValue
    case .manager:
        return Organization.manager.rawValue
    case .teamLead:
        return Organization.teamLead.rawValue
    }

}

print(ranks(type: Organization.boss))

//Add

func student () {
    
   print("I am learning iOS")
}

student()

//Function With Parameters

func totalMarks (english: Int, math: Int) {
    
    let subject = english + math
    
    print("Total Marks of Eng & Math = \(subject)")
}

totalMarks(english: 65, math: 60)

//FUNC WITH IF & ELSE CONDITION

func grade (totalMarks: Int) {
    
    if totalMarks >= 70 && totalMarks < 80 {
        
        print("You Have A Grade")
              
    }else if totalMarks >= 60  && totalMarks < 70 {
        
        print("You Have B Grade")
        
    }else if totalMarks >= 50 && totalMarks < 60 {
        
        print("You Have C Grade")
        
    }else if totalMarks >= 40 && totalMarks < 50 {
        
        print("You Have D Grade")
        
    }else {
        
        print("You are FAIL")
        
    }
}

grade(totalMarks: 70)

//MULITPLICATION

func multiply (num1: Int, num2: Int) ->Int {
    
    let result = num1 * num2
    
    return result
}

var result = multiply(num1: 44, num2: 55)

print("Multiplication of Num1 & Num2 = \(result)")

//FUNCTION WITH RETURN SCORE ///


func addSubjectScore (math: Int, english: Int, urdu: Int) -> Int {
    
    return (math + english + urdu)
}

var totalScore = addSubjectScore(math: 40, english: 50, urdu: 60)

print("TOTAL SUBJECT SCORE = \(totalScore)")


/// BOOLIEN DATA TYPE

func course (student: String) -> Bool {
    
    if student == "Learning iOS" {
        
        return true
        
    }else {
        
      return false
    }
}

var Course = course(student: "Learning iOS")
print(Course)
